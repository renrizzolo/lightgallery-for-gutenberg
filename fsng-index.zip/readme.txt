=== Flexslider for Wordpress Native Gallery ===
Contributors: sarankumar
Tested up to: 4.1.1

WordPress plugin that hacks the gallery[id=\"1,22,... etc \"] shortcode to display a clean basic flexslider instead of the default static thumbnails. No custom classes or extra posts necessary, just use the normal add media button and the nice gallery editor already available. 

== Description ==
WordPress plugin that hacks the gallery[id=\"1,22,... etc \"] shortcode to display a clean basic flexslider instead of the default static thumbnails. No custom classes or extra posts necessary, just use the normal add media button and the nice gallery editor already available. 

== Installation ==
From your WordPress dashboard
Visit \'Plugins > Add New\'
Search for \'Flexslider for Wordpress Native Gallery\'
Activate Flexslider for Wordpress Native Gallery from your Plugins page.
From WordPress.org
Download Flexslider for Wordpress Native Gallery.
Upload the \'Flexslider for Wordpress Native Gallery\' directory to your \'/wp-content/plugins/\' directory, using your favorite method (ftp, sftp, scp, etc...)
Activate Flexslider for Wordpress Native Gallery from your Plugins page. (You will be greeted with a Welcome page.)

== Frequently Asked Questions ==
Can I use my existing WordPress theme?
Yes! Flexslider for Wordpress Native Gallery works out-of-the-box with nearly every WordPress theme.


== Screenshots ==
1. Before Plugin Activation( Gallery images showing as tiled )
2. After plugin activation